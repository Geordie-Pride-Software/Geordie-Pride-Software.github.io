# RCUT2.5-PR1.0.0

Hi there, this is RCUT2.5 public release 1.0.0,
if you need help programming, please open the file" 

``` File PATH
    ~/docs/index.hml
```

For the lisence please read: 

``` File PATH
    lisence.md
```

Hope you enjoy the use of our software :>

RCUT2.5 — Copyright © 2026 Geordie Pride Software